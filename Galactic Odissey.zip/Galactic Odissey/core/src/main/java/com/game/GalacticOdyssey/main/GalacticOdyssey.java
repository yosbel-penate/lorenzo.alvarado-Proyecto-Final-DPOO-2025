package com.game.GalacticOdyssey.main;

import com.badlogic.gdx.ApplicationListener;

public class GalacticOdyssey implements ApplicationListener {
    @Override
    public void create() {

    }

    @Override
    public void resize(int i, int i1) {

    }

    @Override
    public void render() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void dispose() {

    }
}
